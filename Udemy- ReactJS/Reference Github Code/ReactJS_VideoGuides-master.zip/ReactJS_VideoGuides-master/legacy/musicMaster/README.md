#musicMaster

This React application handles web requests through the Spotify API. 