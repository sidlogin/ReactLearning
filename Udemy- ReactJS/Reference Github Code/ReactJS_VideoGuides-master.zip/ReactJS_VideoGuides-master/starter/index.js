import React from 'react';
import ReactDOM from 'react-dom';

// const element = React.createElement('div', null, 'React element!');
const element = <div>React element with JSX!</div>;

ReactDOM.render(element, document.getElementById('root'));