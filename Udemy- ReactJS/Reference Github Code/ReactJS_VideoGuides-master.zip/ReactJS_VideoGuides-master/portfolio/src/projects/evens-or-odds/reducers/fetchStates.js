export default {
  success: 'success',
  error: 'error'
};
