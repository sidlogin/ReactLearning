#goalCoach

This application features redux and a full authentication system through firebase.