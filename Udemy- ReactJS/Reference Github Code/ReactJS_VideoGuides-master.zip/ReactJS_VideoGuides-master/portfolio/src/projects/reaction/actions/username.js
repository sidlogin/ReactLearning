import { SET_USERNAME } from './types';

export const setUsername = username => ({ type: SET_USERNAME, username });
